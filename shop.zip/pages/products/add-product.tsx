import React from "react";
import { AddProductForm } from "@/components";

const AddProduct = () => {
  return (
    <div>
      <AddProductForm />
    </div>
  );
};

export default AddProduct;
